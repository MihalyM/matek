"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var PitagoraszTetelComponent = (function () {
    function PitagoraszTetelComponent() {
    }
    return PitagoraszTetelComponent;
}());
PitagoraszTetelComponent = __decorate([
    core_1.Component({
        selector: 'pitagorasz-tetel',
        templateUrl: 'modules/subjects/trigonometria/pitagorasz-tetel/pitagorasz-tetel.component.html',
        changeDetection: core_1.ChangeDetectionStrategy.OnPush
    })
], PitagoraszTetelComponent);
exports.PitagoraszTetelComponent = PitagoraszTetelComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGl0YWdvcmFzei10ZXRlbC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwaXRhZ29yYXN6LXRldGVsLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFtRTtBQU9uRSxJQUFhLHdCQUF3QjtJQUFyQztJQUF1QyxDQUFDO0lBQUQsK0JBQUM7QUFBRCxDQUFDLEFBQXhDLElBQXdDO0FBQTNCLHdCQUF3QjtJQUxwQyxnQkFBUyxDQUFDO1FBQ1AsUUFBUSxFQUFFLGtCQUFrQjtRQUM1QixXQUFXLEVBQUUsaUZBQWlGO1FBQzlGLGVBQWUsRUFBRSw4QkFBdUIsQ0FBQyxNQUFNO0tBQ2xELENBQUM7R0FDVyx3QkFBd0IsQ0FBRztBQUEzQiw0REFBd0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIENoYW5nZURldGVjdGlvblN0cmF0ZWd5IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAncGl0YWdvcmFzei10ZXRlbCcsXG4gICAgdGVtcGxhdGVVcmw6ICdtb2R1bGVzL3N1YmplY3RzL3RyaWdvbm9tZXRyaWEvcGl0YWdvcmFzei10ZXRlbC9waXRhZ29yYXN6LXRldGVsLmNvbXBvbmVudC5odG1sJyxcbiAgICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaFxufSlcbmV4cG9ydCBjbGFzcyBQaXRhZ29yYXN6VGV0ZWxDb21wb25lbnQge31cbiJdfQ==