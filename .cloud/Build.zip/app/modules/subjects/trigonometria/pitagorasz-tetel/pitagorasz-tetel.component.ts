import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'pitagorasz-tetel',
    templateUrl: 'modules/subjects/trigonometria/pitagorasz-tetel/pitagorasz-tetel.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PitagoraszTetelComponent {}
