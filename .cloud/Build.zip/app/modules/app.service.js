"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var BehaviorSubject_1 = require("rxjs/BehaviorSubject");
var appService = (function () {
    function appService() {
        this.configSubject = new BehaviorSubject_1.BehaviorSubject(null);
        this.config = this.configSubject.asObservable();
        this.account = {
            subjects: [
                {
                    id: 1,
                    title: 'Trigonometria',
                    url: '/subjects/trigonometria',
                    image: 'trigonometria.png',
                    list: [
                        {
                            id: 11,
                            title: 'Pitagorasz tétel',
                            url: '/subjects/trigonometria/pitagorasz-tetel',
                            image: 'pitagorasz-tetel.jpg'
                        },
                        {
                            id: 12,
                            title: 'Masik tétel',
                            url: '/subjects/trigonometria/masik-tetel',
                            image: 'pitagorasz-tetel.jpg'
                        },
                        {
                            id: 13,
                            title: 'Harmadik tétel',
                            url: '/subjects/trigonometria/harmadik-tetel',
                            image: 'pitagorasz-tetel.jpg'
                        }
                    ]
                },
                {
                    id: 2,
                    title: 'Geometria',
                    url: '/subjects/geometria',
                    image: 'geometria.png'
                },
                {
                    id: 3,
                    title: 'Halmazelmélet',
                    url: '/subjects/halmazelmelet',
                    image: 'halmazelmelet.png'
                },
                {
                    id: 4,
                    title: 'Valószínűségszámítás',
                    url: '/subjects/valoszinusegszamitas',
                    image: 'valoszinusegszamitas.png'
                }
            ]
        };
    }
    return appService;
}());
appService = __decorate([
    core_1.Injectable()
], appService);
exports.appService = appService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhcHAuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEyQztBQUMzQyx3REFBdUQ7QUFJdkQsSUFBYSxVQUFVO0lBRHZCO1FBRVUsa0JBQWEsR0FBeUIsSUFBSSxpQ0FBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2pFLFdBQU0sR0FBb0IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUVuRSxZQUFPLEdBQUc7WUFDUixRQUFRLEVBQUU7Z0JBQ1I7b0JBQ0UsRUFBRSxFQUFFLENBQUM7b0JBQ0wsS0FBSyxFQUFFLGVBQWU7b0JBQ3RCLEdBQUcsRUFBRSx5QkFBeUI7b0JBQzlCLEtBQUssRUFBRSxtQkFBbUI7b0JBQzFCLElBQUksRUFBRTt3QkFDSjs0QkFDRSxFQUFFLEVBQUUsRUFBRTs0QkFDTixLQUFLLEVBQUUsa0JBQWtCOzRCQUN6QixHQUFHLEVBQUUsMENBQTBDOzRCQUMvQyxLQUFLLEVBQUUsc0JBQXNCO3lCQUM5Qjt3QkFDRDs0QkFDRSxFQUFFLEVBQUUsRUFBRTs0QkFDTixLQUFLLEVBQUUsYUFBYTs0QkFDcEIsR0FBRyxFQUFFLHFDQUFxQzs0QkFDMUMsS0FBSyxFQUFFLHNCQUFzQjt5QkFDOUI7d0JBQ0Q7NEJBQ0UsRUFBRSxFQUFFLEVBQUU7NEJBQ04sS0FBSyxFQUFFLGdCQUFnQjs0QkFDdkIsR0FBRyxFQUFFLHdDQUF3Qzs0QkFDN0MsS0FBSyxFQUFFLHNCQUFzQjt5QkFDOUI7cUJBQ0Y7aUJBQ0Y7Z0JBQ0Q7b0JBQ0UsRUFBRSxFQUFFLENBQUM7b0JBQ0wsS0FBSyxFQUFFLFdBQVc7b0JBQ2xCLEdBQUcsRUFBRSxxQkFBcUI7b0JBQzFCLEtBQUssRUFBRSxlQUFlO2lCQUN2QjtnQkFDRDtvQkFDRSxFQUFFLEVBQUUsQ0FBQztvQkFDTCxLQUFLLEVBQUUsZUFBZTtvQkFDdEIsR0FBRyxFQUFFLHlCQUF5QjtvQkFDOUIsS0FBSyxFQUFFLG1CQUFtQjtpQkFDM0I7Z0JBQ0Q7b0JBQ0UsRUFBRSxFQUFFLENBQUM7b0JBQ0wsS0FBSyxFQUFFLHNCQUFzQjtvQkFDN0IsR0FBRyxFQUFFLGdDQUFnQztvQkFDckMsS0FBSyxFQUFFLDBCQUEwQjtpQkFDbEM7YUFDRjtTQUNGLENBQUM7SUFDSixDQUFDO0lBQUQsaUJBQUM7QUFBRCxDQUFDLEFBcERELElBb0RDO0FBcERZLFVBQVU7SUFEdEIsaUJBQVUsRUFBRTtHQUNBLFVBQVUsQ0FvRHRCO0FBcERZLGdDQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnOyAgXG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QgfSBmcm9tICdyeGpzL0JlaGF2aW9yU3ViamVjdCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcy9PYnNlcnZhYmxlJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIGFwcFNlcnZpY2UgeyAgXG4gIHByaXZhdGUgY29uZmlnU3ViamVjdDogQmVoYXZpb3JTdWJqZWN0PGFueT4gPSBuZXcgQmVoYXZpb3JTdWJqZWN0KG51bGwpO1xuICBwdWJsaWMgY29uZmlnOiBPYnNlcnZhYmxlPGFueT4gPSB0aGlzLmNvbmZpZ1N1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG5cbiAgYWNjb3VudCA9IHtcbiAgICBzdWJqZWN0czogW1xuICAgICAge1xuICAgICAgICBpZDogMSxcbiAgICAgICAgdGl0bGU6ICdUcmlnb25vbWV0cmlhJyxcbiAgICAgICAgdXJsOiAnL3N1YmplY3RzL3RyaWdvbm9tZXRyaWEnLFxuICAgICAgICBpbWFnZTogJ3RyaWdvbm9tZXRyaWEucG5nJyxcbiAgICAgICAgbGlzdDogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAxMSxcbiAgICAgICAgICAgIHRpdGxlOiAnUGl0YWdvcmFzeiB0w6l0ZWwnLFxuICAgICAgICAgICAgdXJsOiAnL3N1YmplY3RzL3RyaWdvbm9tZXRyaWEvcGl0YWdvcmFzei10ZXRlbCcsXG4gICAgICAgICAgICBpbWFnZTogJ3BpdGFnb3Jhc3otdGV0ZWwuanBnJ1xuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6IDEyLFxuICAgICAgICAgICAgdGl0bGU6ICdNYXNpayB0w6l0ZWwnLFxuICAgICAgICAgICAgdXJsOiAnL3N1YmplY3RzL3RyaWdvbm9tZXRyaWEvbWFzaWstdGV0ZWwnLFxuICAgICAgICAgICAgaW1hZ2U6ICdwaXRhZ29yYXN6LXRldGVsLmpwZydcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAxMyxcbiAgICAgICAgICAgIHRpdGxlOiAnSGFybWFkaWsgdMOpdGVsJyxcbiAgICAgICAgICAgIHVybDogJy9zdWJqZWN0cy90cmlnb25vbWV0cmlhL2hhcm1hZGlrLXRldGVsJyxcbiAgICAgICAgICAgIGltYWdlOiAncGl0YWdvcmFzei10ZXRlbC5qcGcnXG4gICAgICAgICAgfVxuICAgICAgICBdXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogMixcbiAgICAgICAgdGl0bGU6ICdHZW9tZXRyaWEnLFxuICAgICAgICB1cmw6ICcvc3ViamVjdHMvZ2VvbWV0cmlhJyxcbiAgICAgICAgaW1hZ2U6ICdnZW9tZXRyaWEucG5nJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IDMsXG4gICAgICAgIHRpdGxlOiAnSGFsbWF6ZWxtw6lsZXQnLFxuICAgICAgICB1cmw6ICcvc3ViamVjdHMvaGFsbWF6ZWxtZWxldCcsXG4gICAgICAgIGltYWdlOiAnaGFsbWF6ZWxtZWxldC5wbmcnXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogNCxcbiAgICAgICAgdGl0bGU6ICdWYWzDs3N6w61uxbFzw6lnc3rDoW3DrXTDoXMnLFxuICAgICAgICB1cmw6ICcvc3ViamVjdHMvdmFsb3N6aW51c2Vnc3phbWl0YXMnLFxuICAgICAgICBpbWFnZTogJ3ZhbG9zemludXNlZ3N6YW1pdGFzLnBuZydcbiAgICAgIH1cbiAgICBdXG4gIH07XG59Il19